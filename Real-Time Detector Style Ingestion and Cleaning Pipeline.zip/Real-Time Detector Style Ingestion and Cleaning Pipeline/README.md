`README.md`.

# Real-time Detector-style Ingestion & Cleaning Pipeline

This project tests whether cleaning noisy sensor data improves prediction accuracy in a live streaming system.

---

## What problem does this solve?

Real-world sensors produce messy data: noise, drift, missing packets, bad timestamps, and out-of-order values.
Models that use this raw data end up learning those errors instead of the real physical signal.

This project simulates that kind of corrupted data, cleans it in real time, and measures whether a simple prediction model performs better on cleaned data than on raw data.

---

## Architecture

```
Simulator
   ↓
Redis Streams
   ↓
Validator → Observer
   ↓
Preprocessor (cadence, imputation, normalization)
   ↓
Clean Stream
   ↓
Downstream Model
   ↓
Prometheus → Grafana
```

Raw and cleaned data are processed in parallel so their effects on the model can be compared.

---

## How to run

```bash
docker compose up --build
```

Then open:

* Grafana: [http://localhost:3000](http://localhost:3000)
* Prometheus: [http://localhost:9090](http://localhost:9090)
* Login: `admin / admin`

---

## What the dashboards show

The main dashboard compares prediction error for the same model on:

* raw sensor data
* cleaned and normalized sensor data

When the cleaned line stays below the raw line, it means the model is making better predictions using the cleaned data.

---

## What this demonstrates

Under noise, drift, and packet loss, cleaning and normalizing the data makes the model more accurate and more stable.

---

## Downstream model

The downstream model is a simple moving-average predictor.

For each sensor, it keeps the last **N** values and predicts the next value as their average.

Two versions of this model run at the same time:

* one on the raw data stream
* one on the cleaned and normalized stream

For the cleaned stream, values are normalized using a rolling mean and standard deviation.
The model makes predictions in normalized form and then converts them back to real units using:

```
predicted_value = mean + (z_score × standard_deviation)
```

Prediction error is computed as the absolute difference between the predicted value and the actual value.
Both raw and cleaned errors are measured in the same units, so the comparison is fair.

Because both paths use the same model and settings, any difference in error is caused by preprocessing, not by the model.

---

## Experimental setup

Two data paths run at the same time:

**Raw path**
Simulator → Redis → Downstream model

**Clean path**
Simulator → Redis → Validator → Observer → Preprocessor → Clean Redis → Downstream model

The only difference between them is whether the data is cleaned before it reaches the model.

Prediction errors from both paths are recorded continuously and compared.

---

## Dashboards

Grafana dashboards are included in the repository.

To load them:

1. Open Grafana at `http://localhost:3000`
2. Go to **Dashboards → Import**
3. Upload `dashboards/realtime_detector.json`

The main panels show:

* `downstream_raw_prediction_error`
* `downstream_clean_prediction_error`

These let you see how much preprocessing helps over time.

---

## Reproducibility

The whole system runs using Docker Compose, including:

* Redis
* the telemetry pipeline
* Prometheus
* Grafana

Anyone can reproduce the experiment by running:

```bash
docker compose up --build
```

and opening the dashboards.
The same simulator, corruption patterns, preprocessing logic, and model will run each time.

---
